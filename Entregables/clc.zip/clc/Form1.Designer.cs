﻿namespace clc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.por = new System.Windows.Forms.Button();
            this.seis = new System.Windows.Forms.Button();
            this.cinco = new System.Windows.Forms.Button();
            this.cuatro = new System.Windows.Forms.Button();
            this.texto = new System.Windows.Forms.TextBox();
            this.igual = new System.Windows.Forms.Button();
            this.punto = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.cero = new System.Windows.Forms.Button();
            this.entre = new System.Windows.Forms.Button();
            this.nueve = new System.Windows.Forms.Button();
            this.ocho = new System.Windows.Forms.Button();
            this.siete = new System.Windows.Forms.Button();
            this.menos = new System.Windows.Forms.Button();
            this.tres = new System.Windows.Forms.Button();
            this.dos = new System.Windows.Forms.Button();
            this.uno = new System.Windows.Forms.Button();
            this.mas = new System.Windows.Forms.Button();
            this.cuadrado = new System.Windows.Forms.Button();
            this.raiz = new System.Windows.Forms.Button();
            this.borrar = new System.Windows.Forms.Button();
            this.masmenos = new System.Windows.Forms.Button();
            this.c = new System.Windows.Forms.Button();
            this.ce = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // por
            // 
            this.por.AutoSize = true;
            this.por.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.por.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.por.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.por.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.por.Location = new System.Drawing.Point(175, 129);
            this.por.Name = "por";
            this.por.Size = new System.Drawing.Size(86, 60);
            this.por.TabIndex = 74;
            this.por.Text = "x";
            this.por.UseVisualStyleBackColor = false;
            this.por.Click += new System.EventHandler(this.BotonOperacion);
            // 
            // seis
            // 
            this.seis.AutoSize = true;
            this.seis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.seis.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.seis.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seis.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.seis.Location = new System.Drawing.Point(175, 251);
            this.seis.Name = "seis";
            this.seis.Size = new System.Drawing.Size(86, 60);
            this.seis.TabIndex = 73;
            this.seis.Text = "6";
            this.seis.UseVisualStyleBackColor = false;
            this.seis.Click += new System.EventHandler(this.BotonNum);
            // 
            // cinco
            // 
            this.cinco.AutoSize = true;
            this.cinco.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.cinco.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cinco.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cinco.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cinco.Location = new System.Drawing.Point(89, 251);
            this.cinco.Name = "cinco";
            this.cinco.Size = new System.Drawing.Size(86, 60);
            this.cinco.TabIndex = 72;
            this.cinco.Text = "5";
            this.cinco.UseVisualStyleBackColor = false;
            this.cinco.Click += new System.EventHandler(this.BotonNum);
            // 
            // cuatro
            // 
            this.cuatro.AutoSize = true;
            this.cuatro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.cuatro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cuatro.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cuatro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cuatro.Location = new System.Drawing.Point(3, 251);
            this.cuatro.Name = "cuatro";
            this.cuatro.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cuatro.Size = new System.Drawing.Size(86, 60);
            this.cuatro.TabIndex = 71;
            this.cuatro.Text = "4";
            this.cuatro.UseVisualStyleBackColor = false;
            this.cuatro.Click += new System.EventHandler(this.BotonNum);
            // 
            // texto
            // 
            this.texto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(42)))), ((int)(((byte)(49)))));
            this.texto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.texto.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.texto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.texto.Location = new System.Drawing.Point(3, 3);
            this.texto.Multiline = true;
            this.texto.Name = "texto";
            this.texto.ReadOnly = true;
            this.texto.Size = new System.Drawing.Size(344, 59);
            this.texto.TabIndex = 70;
            this.texto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.texto.TextChanged += new System.EventHandler(this.texto_TextChanged);
            // 
            // igual
            // 
            this.igual.AutoSize = true;
            this.igual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.igual.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.igual.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.igual.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.igual.Location = new System.Drawing.Point(261, 312);
            this.igual.Name = "igual";
            this.igual.Size = new System.Drawing.Size(86, 121);
            this.igual.TabIndex = 69;
            this.igual.Text = "=";
            this.igual.UseVisualStyleBackColor = false;
            this.igual.Click += new System.EventHandler(this.BotonIgual);
            // 
            // punto
            // 
            this.punto.AutoSize = true;
            this.punto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.punto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.punto.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.punto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.punto.Location = new System.Drawing.Point(175, 373);
            this.punto.Name = "punto";
            this.punto.Size = new System.Drawing.Size(86, 60);
            this.punto.TabIndex = 68;
            this.punto.Text = ".";
            this.punto.UseVisualStyleBackColor = false;
            this.punto.Click += new System.EventHandler(this.BotonPunto);
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button19.Location = new System.Drawing.Point(89, 378);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(0, 0);
            this.button19.TabIndex = 67;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // cero
            // 
            this.cero.AutoSize = true;
            this.cero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.cero.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cero.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cero.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cero.Location = new System.Drawing.Point(3, 373);
            this.cero.Name = "cero";
            this.cero.Size = new System.Drawing.Size(172, 60);
            this.cero.TabIndex = 66;
            this.cero.Text = "0";
            this.cero.UseVisualStyleBackColor = false;
            this.cero.Click += new System.EventHandler(this.BotonNum);
            // 
            // entre
            // 
            this.entre.AutoSize = true;
            this.entre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.entre.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.entre.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.entre.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.entre.Location = new System.Drawing.Point(261, 129);
            this.entre.Name = "entre";
            this.entre.Size = new System.Drawing.Size(86, 60);
            this.entre.TabIndex = 65;
            this.entre.Text = "/";
            this.entre.UseVisualStyleBackColor = false;
            this.entre.Click += new System.EventHandler(this.BotonOperacion);
            // 
            // nueve
            // 
            this.nueve.AutoSize = true;
            this.nueve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.nueve.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.nueve.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nueve.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.nueve.Location = new System.Drawing.Point(175, 312);
            this.nueve.Name = "nueve";
            this.nueve.Size = new System.Drawing.Size(86, 60);
            this.nueve.TabIndex = 64;
            this.nueve.Text = "9";
            this.nueve.UseVisualStyleBackColor = false;
            this.nueve.Click += new System.EventHandler(this.BotonNum);
            // 
            // ocho
            // 
            this.ocho.AutoSize = true;
            this.ocho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.ocho.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ocho.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ocho.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ocho.Location = new System.Drawing.Point(89, 312);
            this.ocho.Name = "ocho";
            this.ocho.Size = new System.Drawing.Size(86, 60);
            this.ocho.TabIndex = 63;
            this.ocho.Text = "8";
            this.ocho.UseVisualStyleBackColor = false;
            this.ocho.Click += new System.EventHandler(this.BotonNum);
            // 
            // siete
            // 
            this.siete.AutoSize = true;
            this.siete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.siete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.siete.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.siete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.siete.Location = new System.Drawing.Point(3, 312);
            this.siete.Name = "siete";
            this.siete.Size = new System.Drawing.Size(86, 60);
            this.siete.TabIndex = 62;
            this.siete.Text = "7";
            this.siete.UseVisualStyleBackColor = false;
            this.siete.Click += new System.EventHandler(this.BotonNum);
            // 
            // menos
            // 
            this.menos.AutoSize = true;
            this.menos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.menos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.menos.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.menos.Location = new System.Drawing.Point(89, 129);
            this.menos.Name = "menos";
            this.menos.Size = new System.Drawing.Size(86, 60);
            this.menos.TabIndex = 61;
            this.menos.Text = "-";
            this.menos.UseVisualStyleBackColor = false;
            this.menos.Click += new System.EventHandler(this.BotonOperacion);
            // 
            // tres
            // 
            this.tres.AutoSize = true;
            this.tres.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.tres.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tres.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tres.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tres.Location = new System.Drawing.Point(175, 190);
            this.tres.Name = "tres";
            this.tres.Size = new System.Drawing.Size(86, 60);
            this.tres.TabIndex = 60;
            this.tres.Text = "3";
            this.tres.UseVisualStyleBackColor = false;
            this.tres.Click += new System.EventHandler(this.BotonNum);
            // 
            // dos
            // 
            this.dos.AutoSize = true;
            this.dos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.dos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dos.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dos.Location = new System.Drawing.Point(89, 190);
            this.dos.Name = "dos";
            this.dos.Size = new System.Drawing.Size(86, 60);
            this.dos.TabIndex = 59;
            this.dos.Text = "2";
            this.dos.UseVisualStyleBackColor = false;
            this.dos.Click += new System.EventHandler(this.BotonNum);
            // 
            // uno
            // 
            this.uno.AutoSize = true;
            this.uno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(95)))), ((int)(((byte)(100)))));
            this.uno.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.uno.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uno.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.uno.Location = new System.Drawing.Point(3, 190);
            this.uno.Name = "uno";
            this.uno.Size = new System.Drawing.Size(86, 60);
            this.uno.TabIndex = 58;
            this.uno.Text = "1";
            this.uno.UseVisualStyleBackColor = false;
            this.uno.Click += new System.EventHandler(this.BotonNum);
            // 
            // mas
            // 
            this.mas.AutoSize = true;
            this.mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.mas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.mas.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.mas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.mas.Location = new System.Drawing.Point(3, 129);
            this.mas.Name = "mas";
            this.mas.Size = new System.Drawing.Size(86, 60);
            this.mas.TabIndex = 57;
            this.mas.Text = "+";
            this.mas.UseVisualStyleBackColor = false;
            this.mas.Click += new System.EventHandler(this.BotonOperacion);
            // 
            // cuadrado
            // 
            this.cuadrado.AutoSize = true;
            this.cuadrado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.cuadrado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cuadrado.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cuadrado.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cuadrado.Location = new System.Drawing.Point(261, 251);
            this.cuadrado.Name = "cuadrado";
            this.cuadrado.Size = new System.Drawing.Size(86, 60);
            this.cuadrado.TabIndex = 55;
            this.cuadrado.Text = "x²";
            this.cuadrado.UseVisualStyleBackColor = false;
            this.cuadrado.Click += new System.EventHandler(this.BotonOperacion);
            // 
            // raiz
            // 
            this.raiz.AutoSize = true;
            this.raiz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(62)))), ((int)(((byte)(145)))));
            this.raiz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.raiz.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.raiz.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.raiz.Location = new System.Drawing.Point(261, 190);
            this.raiz.Name = "raiz";
            this.raiz.Size = new System.Drawing.Size(86, 60);
            this.raiz.TabIndex = 54;
            this.raiz.Text = "√";
            this.raiz.UseVisualStyleBackColor = false;
            this.raiz.Click += new System.EventHandler(this.BotonOperacion);
            // 
            // borrar
            // 
            this.borrar.AutoSize = true;
            this.borrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.borrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.borrar.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.borrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.borrar.Location = new System.Drawing.Point(261, 68);
            this.borrar.Name = "borrar";
            this.borrar.Size = new System.Drawing.Size(86, 60);
            this.borrar.TabIndex = 53;
            this.borrar.Text = "◄";
            this.borrar.UseVisualStyleBackColor = false;
            this.borrar.Click += new System.EventHandler(this.Borra);
            // 
            // masmenos
            // 
            this.masmenos.AutoSize = true;
            this.masmenos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.masmenos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.masmenos.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.masmenos.ForeColor = System.Drawing.Color.White;
            this.masmenos.Location = new System.Drawing.Point(175, 68);
            this.masmenos.Name = "masmenos";
            this.masmenos.Size = new System.Drawing.Size(86, 60);
            this.masmenos.TabIndex = 52;
            this.masmenos.Text = "±";
            this.masmenos.UseVisualStyleBackColor = false;
            this.masmenos.Click += new System.EventHandler(this.Masmenos);
            // 
            // c
            // 
            this.c.AutoSize = true;
            this.c.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.c.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.c.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.c.ForeColor = System.Drawing.Color.White;
            this.c.Location = new System.Drawing.Point(89, 68);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(86, 60);
            this.c.TabIndex = 51;
            this.c.Text = "C";
            this.c.UseVisualStyleBackColor = false;
            this.c.Click += new System.EventHandler(this.BotonC);
            // 
            // ce
            // 
            this.ce.AutoSize = true;
            this.ce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.ce.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ce.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ce.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ce.Location = new System.Drawing.Point(3, 68);
            this.ce.Name = "ce";
            this.ce.Size = new System.Drawing.Size(86, 60);
            this.ce.TabIndex = 50;
            this.ce.Text = "CE";
            this.ce.UseVisualStyleBackColor = false;
            this.ce.Click += new System.EventHandler(this.BotonCe);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(42)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(350, 435);
            this.Controls.Add(this.por);
            this.Controls.Add(this.seis);
            this.Controls.Add(this.cinco);
            this.Controls.Add(this.cuatro);
            this.Controls.Add(this.texto);
            this.Controls.Add(this.igual);
            this.Controls.Add(this.punto);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.cero);
            this.Controls.Add(this.entre);
            this.Controls.Add(this.nueve);
            this.Controls.Add(this.ocho);
            this.Controls.Add(this.siete);
            this.Controls.Add(this.menos);
            this.Controls.Add(this.tres);
            this.Controls.Add(this.dos);
            this.Controls.Add(this.uno);
            this.Controls.Add(this.mas);
            this.Controls.Add(this.cuadrado);
            this.Controls.Add(this.raiz);
            this.Controls.Add(this.borrar);
            this.Controls.Add(this.masmenos);
            this.Controls.Add(this.c);
            this.Controls.Add(this.ce);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Calculadora Estandar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button por;
        private Button seis;
        private Button cinco;
        private Button cuatro;
        private TextBox texto;
        private Button igual;
        private Button punto;
        private Button button19;
        private Button cero;
        private Button entre;
        private Button nueve;
        private Button ocho;
        private Button siete;
        private Button menos;
        private Button tres;
        private Button dos;
        private Button uno;
        private Button mas;
        private Button cuadrado;
        private Button raiz;
        private Button borrar;
        private Button masmenos;
        private Button c;
        private Button ce;
    }
}